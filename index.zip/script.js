document.addEventListener('DOMContentLoaded', () => {

    // ── 1. Sidebar Navigation ──
    const navItems = document.querySelectorAll('.nav-item');
    const tabContents = document.querySelectorAll('.tab-content');
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(nav => nav.classList.remove('active'));
            tabContents.forEach(tab => tab.classList.remove('active'));
            item.classList.add('active');
            document.getElementById(item.getAttribute('data-tab')).classList.add('active');
            closeSidebar();
        });
    });

    // ── 2. Mobile Hamburger ──
    const sidebar = document.querySelector('.sidebar');
    const hamburger = document.getElementById('hamburger');
    const sidebarOverlay = document.getElementById('sidebar-overlay');

    function openSidebar() {
        sidebar.classList.add('open');
        sidebarOverlay.classList.add('active');
    }
    function closeSidebar() {
        sidebar.classList.remove('open');
        sidebarOverlay.classList.remove('active');
    }

    if (hamburger) {
        hamburger.addEventListener('click', () => {
            sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
        });
    }
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', closeSidebar);
    }

    // ── 3. Platform Tabs (Discovery) ──
    const platformTabs = document.querySelectorAll('.p-tab');
    const platformPlaceholder = document.getElementById('platform-placeholder');
    const discoveryContent = document.getElementById('discovery-content');
    const platformNames = {
        'Telegram': null,
        'VKontakte': 'VKontakte',
        'Instagram': 'Instagram',
        'Threads': 'Threads',
        'МАХ': 'МАХ',
        'Одноклассники': 'Одноклассники'
    };

    platformTabs.forEach(item => {
        item.addEventListener('click', () => {
            platformTabs.forEach(tab => {
                tab.classList.remove('active');
                tab.setAttribute('aria-selected', 'false');
            });
            item.classList.add('active');
            item.setAttribute('aria-selected', 'true');

            const name = item.textContent.trim();
            if (name === 'Telegram') {
                if (discoveryContent) discoveryContent.style.display = '';
                if (platformPlaceholder) platformPlaceholder.classList.remove('active');
            } else {
                if (discoveryContent) discoveryContent.style.display = 'none';
                if (platformPlaceholder) {
                    platformPlaceholder.textContent = 'Подключите ' + name + ', чтобы видеть результаты. Перейдите в «Каналы для поиска лидов».';
                    platformPlaceholder.classList.add('active');
                }
            }
        });
    });

    // ── 4. Discovery Mode Toggle (Expert / Auto / Channels) ──
    const modeBtns = document.querySelectorAll('#funnel-mode .toggle-btn');
    const expertView = document.getElementById('expert-view');
    const autoView = document.getElementById('auto-view');
    const discoveryMain = document.getElementById('discovery-main');

    if (expertView) expertView.style.display = 'none';
    if (autoView) autoView.style.display = 'block';

    modeBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            modeBtns.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            if (e.target.getAttribute('data-mode') === 'expert') {
                expertView.style.display = 'block';
                autoView.style.display = 'none';
            } else {
                expertView.style.display = 'none';
                autoView.style.display = 'block';
            }
        });
    });

    // ── 5. Inbox Toggle (Kanban / Classic) ──
    const inboxToggleBtns = document.querySelectorAll('#inbox-view-toggle .toggle-btn');
    const kanbanView = document.getElementById('kanban-view');
    const classicView = document.getElementById('classic-view');

    inboxToggleBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            inboxToggleBtns.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            if (e.target.getAttribute('data-view') === 'kanban') {
                kanbanView.style.display = 'flex';
                classicView.classList.remove('active');
            } else {
                kanbanView.style.display = 'none';
                classicView.classList.add('active');
            }
        });
    });

    // ── 6. Analytics Toggle ──
    const analyticsBtns = document.querySelectorAll('#analytics-toggle .toggle-btn');
    analyticsBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            analyticsBtns.forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
        });
    });

    // ── 7. Classic Inbox Chat Selection ──
    const ciItems = document.querySelectorAll('.ci-item');
    ciItems.forEach(item => {
        item.addEventListener('click', () => {
            ciItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');
        });
    });

    // ── 8. Toast System ──
    const toastContainer = document.getElementById('toast-container');

    function showToast(message, type, link) {
        type = type || 'success';
        const toast = document.createElement('div');
        toast.className = 'toast' + (type !== 'success' ? ' toast--' + type : '');

        const iconClass = 'toast-icon toast-icon--' + type;
        const iconSymbol = type === 'error' ? '✕' : '✓';

        let html = '<div class="' + iconClass + '">' + iconSymbol + '</div>';
        html += '<div><div class="toast-text">' + message + '</div>';
        if (link) {
            html += '<div class="toast-link" data-tab="' + link.tab + '">' + link.text + '</div>';
        }
        html += '</div>';

        toast.innerHTML = html;
        toastContainer.appendChild(toast);

        const toastLink = toast.querySelector('.toast-link');
        if (toastLink) {
            toastLink.addEventListener('click', () => {
                const tab = toastLink.getAttribute('data-tab');
                if (tab) {
                    const navItem = document.querySelector('.nav-item[data-tab="' + tab + '"]');
                    if (navItem) navItem.click();
                }
            });
        }

        setTimeout(() => toast.remove(), 3000);
    }

    // Toast bindings with contextual messages
    const toastMappings = {
        'Сценарий активирован!': { msg: 'Автоответ активен. Проверьте статус в Inbox.', link: { tab: 'inbox', text: 'Перейти в Inbox →' } },
        'Словарные правила обновлены!': { msg: 'Фильтры сохранены. Новые результаты появятся в течение минуты.' },
        'Профиль компании успешно сохранен в ядро ИИ!': { msg: 'Профиль сохранён. Теперь настройте поиск лидов.', link: { tab: 'discovery', text: 'Перейти к поиску →' } }
    };

    document.querySelectorAll('.show-toast').forEach(btn => {
        btn.addEventListener('click', () => {
            const rawMsg = btn.getAttribute('data-msg') || 'Выполнено';
            const mapping = toastMappings[rawMsg];
            if (mapping) {
                showToast(mapping.msg, 'success', mapping.link);
            } else {
                showToast(rawMsg);
            }

            if (btn.classList.contains('btn-primary') || btn.classList.contains('btn-outline')) {
                btn.classList.add('btn-loading');
                setTimeout(() => btn.classList.remove('btn-loading'), 1200);
            }
        });
    });

    // ── 9. Cmd+K Modal ──
    const cmdModal = document.getElementById('cmd-modal-overlay');
    const cmdInput = document.querySelector('.cmd-input');
    const cmdItems = document.querySelectorAll('.cmd-item');
    const cmdNoResults = document.querySelector('.cmd-no-results');
    let cmdActiveIndex = -1;

    function openCmdModal() {
        cmdModal.classList.add('active');
        cmdInput.value = '';
        cmdItems.forEach(i => { i.classList.remove('hidden'); i.classList.remove('active'); });
        if (cmdNoResults) cmdNoResults.style.display = 'none';
        cmdActiveIndex = -1;
        setTimeout(() => cmdInput.focus(), 50);
    }
    function closeCmdModal() {
        cmdModal.classList.remove('active');
    }

    document.addEventListener('keydown', (e) => {
        if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
            e.preventDefault();
            openCmdModal();
        }
        if (e.key === 'Escape' && cmdModal.classList.contains('active')) {
            closeCmdModal();
        }
    });

    cmdModal.addEventListener('click', (e) => {
        if (e.target === cmdModal) closeCmdModal();
    });

    const sidebarSearchBtn = document.getElementById('sidebar-search-btn');
    if (sidebarSearchBtn) {
        sidebarSearchBtn.addEventListener('click', openCmdModal);
    }

    // Cmd+K filtering
    if (cmdInput) {
        cmdInput.addEventListener('input', () => {
            const query = cmdInput.value.toLowerCase().trim();
            let visibleCount = 0;
            cmdActiveIndex = -1;
            cmdItems.forEach(item => {
                item.classList.remove('active');
                const text = item.textContent.toLowerCase();
                if (query === '' || text.includes(query)) {
                    item.classList.remove('hidden');
                    visibleCount++;
                } else {
                    item.classList.add('hidden');
                }
            });
            if (cmdNoResults) {
                cmdNoResults.style.display = visibleCount === 0 ? 'block' : 'none';
            }
        });
    }

    // Cmd+K keyboard navigation
    if (cmdInput) {
        cmdInput.addEventListener('keydown', (e) => {
            const visible = Array.from(cmdItems).filter(i => !i.classList.contains('hidden'));
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                cmdActiveIndex = Math.min(cmdActiveIndex + 1, visible.length - 1);
                updateCmdHighlight(visible);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                cmdActiveIndex = Math.max(cmdActiveIndex - 1, 0);
                updateCmdHighlight(visible);
            } else if (e.key === 'Enter' && cmdActiveIndex >= 0 && visible[cmdActiveIndex]) {
                e.preventDefault();
                visible[cmdActiveIndex].click();
            }
        });
    }

    function updateCmdHighlight(visible) {
        cmdItems.forEach(i => i.classList.remove('active'));
        if (visible[cmdActiveIndex]) {
            visible[cmdActiveIndex].classList.add('active');
            visible[cmdActiveIndex].scrollIntoView({ block: 'nearest' });
        }
    }

    // Cmd item click handlers
    cmdItems.forEach(item => {
        item.addEventListener('click', () => {
            const tab = item.getAttribute('data-nav');
            if (tab) {
                const navItem = document.querySelector('.nav-item[data-tab="' + tab + '"]');
                if (navItem) navItem.click();
            }
            closeCmdModal();
        });
    });

    // ── 10. Drag & Drop (Kanban) ──
    const kanbanCards = document.querySelectorAll('.kanban-card');
    const kanbanCols = document.querySelectorAll('.kanban-col');
    let draggedCard = null;

    kanbanCards.forEach(card => {
        card.addEventListener('dragstart', function () {
            draggedCard = this;
            setTimeout(() => this.classList.add('dragging'), 0);
        });
        card.addEventListener('dragend', function () {
            this.classList.remove('dragging');
            draggedCard = null;
            updateColCounts();
        });
    });

    kanbanCols.forEach(col => {
        col.addEventListener('dragover', function (e) {
            e.preventDefault();
            this.classList.add('drag-over');
        });
        col.addEventListener('dragleave', function () {
            this.classList.remove('drag-over');
        });
        col.addEventListener('drop', function () {
            this.classList.remove('drag-over');
            if (draggedCard) {
                this.appendChild(draggedCard);
                showToast('Статус лида обновлён');
            }
        });
    });

    function updateColCounts() {
        kanbanCols.forEach(col => {
            const count = col.querySelectorAll('.kanban-card').length;
            col.querySelector('.col-count').textContent = count;
        });
    }

    // ── 11. Settings Form ──
    const settingsForm = document.getElementById('settings-form');
    const settingsSaveBtn = document.getElementById('settings-save');

    if (settingsForm && settingsSaveBtn) {
        const originalValues = {};
        settingsForm.querySelectorAll('input').forEach(input => {
            originalValues[input.name] = input.value;
        });
        settingsSaveBtn.disabled = true;

        settingsForm.addEventListener('input', () => {
            let changed = false;
            settingsForm.querySelectorAll('input').forEach(input => {
                if (input.value !== originalValues[input.name]) changed = true;
            });
            settingsSaveBtn.disabled = !changed;
        });
    }

    // ── 12. Prompt Cards (About page) ──
    document.querySelectorAll('.prompt-edit-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const card = btn.closest('.prompt-card');
            const textarea = card.querySelector('.prompt-textarea');
            if (textarea.hasAttribute('readonly')) {
                textarea.removeAttribute('readonly');
                textarea.focus();
                btn.innerHTML = '<i data-lucide="check"></i> Сохранить';
                if (typeof lucide !== 'undefined') lucide.createIcons();
            } else {
                textarea.setAttribute('readonly', '');
                btn.innerHTML = '<i data-lucide="pencil"></i> Редактировать вручную';
                if (typeof lucide !== 'undefined') lucide.createIcons();
                showToast('Промпт сохранён');
            }
        });
    });

    document.querySelectorAll('.prompt-ai-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const card = btn.closest('.prompt-card');
            const textarea = card.querySelector('.prompt-textarea');
            const improved = btn.getAttribute('data-improved');
            btn.classList.add('btn-loading');
            setTimeout(() => {
                btn.classList.remove('btn-loading');
                textarea.value = improved;
                textarea.setAttribute('readonly', '');
                const editBtn = card.querySelector('.prompt-edit-btn');
                if (editBtn) {
                    editBtn.innerHTML = '<i data-lucide="pencil"></i> Редактировать вручную';
                    if (typeof lucide !== 'undefined') lucide.createIcons();
                }
                showToast('Промпт улучшен с помощью ИИ');
            }, 1500);
        });
    });

    // ── 13. Lead Dialog (Inbox) ──
    const leadDialogOverlay = document.getElementById('lead-dialog-overlay');
    const leadDialogName = leadDialogOverlay ? leadDialogOverlay.querySelector('.lead-dialog-name') : null;
    const leadDialogPlatform = leadDialogOverlay ? leadDialogOverlay.querySelector('.lead-dialog-platform') : null;
    const leadDialogCloseBtn = leadDialogOverlay ? leadDialogOverlay.querySelector('.lead-dialog-close') : null;
    const leadDialogExternalBtn = leadDialogOverlay ? leadDialogOverlay.querySelector('.lead-dialog-external') : null;
    const leadDialogSendBtn = leadDialogOverlay ? leadDialogOverlay.querySelector('.lead-dialog-send') : null;
    const leadDialogInput = leadDialogOverlay ? leadDialogOverlay.querySelector('.lead-dialog-input') : null;
    let wasDragged = false;

    function openLeadDialog(name, platformTag) {
        if (!leadDialogOverlay) return;
        if (leadDialogName) leadDialogName.textContent = name;
        if (leadDialogPlatform) {
            leadDialogPlatform.className = 'c-tag lead-dialog-platform';
            if (platformTag) {
                leadDialogPlatform.textContent = platformTag;
                const tagLower = platformTag.toLowerCase();
                if (tagLower.includes('telegram')) leadDialogPlatform.classList.add('c-tag--telegram');
                else if (tagLower.includes('vk')) leadDialogPlatform.classList.add('c-tag--vk');
                else if (tagLower.includes('insta')) leadDialogPlatform.classList.add('c-tag--instagram');
            }
        }
        leadDialogOverlay.classList.add('active');
    }
    function closeLeadDialog() {
        if (leadDialogOverlay) leadDialogOverlay.classList.remove('active');
    }

    if (leadDialogCloseBtn) leadDialogCloseBtn.addEventListener('click', closeLeadDialog);
    if (leadDialogOverlay) {
        leadDialogOverlay.addEventListener('click', (e) => {
            if (e.target === leadDialogOverlay) closeLeadDialog();
        });
    }
    if (leadDialogExternalBtn) {
        leadDialogExternalBtn.addEventListener('click', () => showToast('Открытие профиля лида...', 'info'));
    }
    if (leadDialogSendBtn && leadDialogInput) {
        leadDialogSendBtn.addEventListener('click', () => {
            if (leadDialogInput.value.trim()) {
                showToast('Сообщение отправлено!');
                leadDialogInput.value = '';
            }
        });
    }

    document.querySelectorAll('.kanban-card').forEach(card => {
        card.addEventListener('dragstart', () => { wasDragged = true; });
        card.addEventListener('click', (e) => {
            if (wasDragged) { wasDragged = false; return; }
            if (e.target.closest('.lead-link')) return;
            const name = card.querySelector('.card-title') ? card.querySelector('.card-title').textContent : 'Лид';
            const tagEl = card.querySelector('.c-tag:not(.c-tag--hot):not(.c-tag--success)');
            const platform = tagEl ? tagEl.textContent.trim() : '';
            openLeadDialog(name, platform);
        });
    });

    // ── 14. Lead Link Buttons ──
    document.querySelectorAll('.lead-link').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            showToast('Открытие профиля лида...', 'info');
        });
    });

    // ── 15. Team Page ──
    document.querySelectorAll('.team-role-select').forEach(select => {
        select.addEventListener('change', () => {
            showToast('Роль обновлена');
        });
    });

    // ── 16. Initialize Lucide Icons ──
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

});
